function [A_t, Z_t, U_t, H_s, H_c] = adimc(X_t, H_prev, lambda1, lambda2, lambda3, gamma, max_iter, m, k, sigma_scale)
% 增量多视图聚类优化函数
% 输入:
%   X_t     : d x n 当前视图数据矩阵
%   H_prev  : k x n 上一视图的历史知识 (t=1时为空[])
%   lambda1, lambda2, lambda3, gamma : 正则化参数
%   max_iter: 最大迭代次数
%   m       : 锚点数量
%   k       : 潜在特征维度
% 输出:
%   A_t, Z_t, U_t, H_s, H_c : 优化后的变量

[d, n] = size(X_t);

tolfun=1e-6;

% ========== 初始化变量 ==========
% 初始化 A_t (d x m 正交矩阵)
% A_t = randn(d, m);
% [Q, ~] = qr(A_t, 0);
% A_t = Q(:, 1:m);
A_t = zeros(d, m);

% 初始化 Z_t (m x n 非负且列和为1)
% Z_t = abs(randn(m, n));
% Z_t = Z_t ./ sum(Z_t, 1);
Z_t = zeros(m, n);
% Z_t(:,1:m)=eye(m);

% if nargin < 10 || isempty(sigma_scale)
    % sigma_scale = 0.5;  % 默认带宽缩放因子
% end

% % ========== k-means初始化A_t和Z_t ==========

%%%%斯密特正交化？

% 初始化 U_t (m x k 正交矩阵)


U_t = zeros(m, k);
% U_t = eye(m, k);




% 初始化 H_s 和 H_c (k x n)
% H_s = 0.1 * randn(k, n);



% if isempty(H_prev)
    % H_c=zeros(k,n);  % t=1: 随机初始化
% else
    % H_c = H_prev;             % t>1: 使用历史知识
% end

H_s=zeros(k,n);

H_c=zeros(k,n);

obj=[];


% H_quad = 2*(1 + lambda1) * eye(m); % 对角Hessian矩阵
% H_quad = (H_quad+H_quad')/2;
% options = optimset( 'Algorithm','interior-point-convex','Display','off');

% ========== 交替优化 ==========
for iter = 1:max_iter
    % --- 1. 更新 A_t (正交Procrustes问题) ---
    [U, ~, V] = svd(X_t * Z_t', 'econ');
    A_t = U * V';
    
    % --- 2. 更新Z_t (使用闭式解+单纯形投影) ---
    H_comb = H_s + H_c;
    % 无约束闭式解
    Z_temp = (A_t' * X_t + lambda1 * U_t * H_comb) / (1 + lambda1);
	
	% 投影到概率单纯形 (非负且列和为1)
	for j = 1:n
        Z_t(:, j) = EProjSimplex_new(Z_temp(:, j), 1);
    end
    
    % --- 3. 更新 U_t (正交Procrustes问题) ---
    [U, ~, V] = svd(Z_t * H_comb', 'econ');
    U_t = U * V';
	
	[H_s, H_c] = update_H(Z_t, U_t, H_c, H_s, H_prev, lambda1, lambda2, lambda3, gamma);
	
    
    % % --- 可选: 计算目标函数值 ---
    obj(iter) = calculate_obj(X_t, A_t, Z_t, U_t, H_s, H_c, H_prev, ...
                             lambda1, lambda2, lambda3, gamma);
	if(iter>=2&&(abs(obj(iter-1)-obj(iter))<tolfun))
		break;
	end
    % fprintf('Iter %d, Obj=%.4f\n', iter, obj(iter));
end
end













% 辅助函数：计算目标函数值
function obj = calculate_obj(X_t, A_t, Z_t, U_t, H_s, H_c, H_prev, ...
                            lambda1, lambda2, lambda3, gamma)
    term1 = norm(X_t - A_t*Z_t, 'fro')^2;
    term2 = lambda1 * norm(Z_t - U_t*(H_s + H_c), 'fro')^2;
    term3 = gamma * (norm(H_s, 'fro')^2 + norm(H_c, 'fro')^2);
    term4 = lambda3 * sum(abs(H_c .* H_s), 'all');
    
    if isempty(H_prev)
        term5 = 0;
    else
        term5 = lambda2 * norm(H_c - H_prev, 'fro')^2;
    end
    
    obj = term1 + term2 + term3 + term4 + term5;
end