function [H_s, H_c] = update_H(Z_t, U_t, H_c, H_s, H_prev, lambda1, lambda2, lambda3, gamma)
% 优化 H_t^s 和 H_t^c 的闭式解
% 输入:
%   Z_t: m x n 锚图矩阵
%   U_t: m x k 正交矩阵
%   H_prev: k x n 前一视图的历史知识 (t=1 时为空 [])
%   lambda1, lambda2, lambda3, gamma: 正则化参数
% 输出:
%   H_s, H_c: 优化后的 k x n 矩阵

% % ========== 1. 优化 H_t^s ==========
% % 计算中间项
% R_c = Z_t - U_t * H_c;  % 残差（固定 H_c）
% C_s = U_t' * R_c;       % 投影到潜在空间

% % 计算软阈值参数
% eta_s = lambda3 / lambda1 ;
% W_s = eta_s * abs(H_c); % 权重矩阵（基于 H_c）


% % 应用软阈值算子
% H_s = sign(C_s) .* max(abs(C_s) - W_s, 0);




% ========== 1. 优化 H_t^s ==========
% 计算中间项
R_c = Z_t - U_t * H_c;  % 残差（固定 H_c）
C_s = U_t' * R_c;       % 投影到潜在空间

% 计算软阈值参数 (包含gamma项)
eta_s = lambda3 / (lambda1 + gamma);
W_s = eta_s * abs(H_c); % 权重矩阵（基于 H_c）

% 计算目标点 (包含gamma项)
D_s = (lambda1 / (lambda1 + gamma)) * C_s;

% 应用软阈值算子
H_s = sign(D_s) .* max(abs(D_s) - W_s, 0);

% ========== 2. 优化 H_t^c ==========
% 计算中间项
R_s = Z_t - U_t * H_s;  % 残差（使用更新后的 H_s）
C_c = U_t' * R_s;       % 投影到潜在空间

if isempty(H_prev)
    % t = 1: 无历史对齐项
    eta_c = lambda3 / (lambda1 + gamma);
    W_c = eta_c * abs(H_s); % 权重矩阵（基于 H_s）
	
	F_c=(lambda1 / (lambda1 + gamma)) * C_c;
    
    % 应用软阈值算子
    H_c = sign(F_c) .* max(abs(F_c) - W_c, 0);
else
    % t > 1: 包含历史对齐项
    eta_c = lambda3 / (lambda1 + lambda2 + gamma);
    W_c = eta_c * abs(H_s); % 权重矩阵（基于 H_s）
    
    % 计算加权平均 (包含gamma项)
    E_c = (lambda1 * C_c + lambda2 * H_prev) / (lambda1 + lambda2 + gamma);
    
    % 应用软阈值算子
    H_c = sign(E_c) .* max(abs(E_c) - W_c, 0);
end
end