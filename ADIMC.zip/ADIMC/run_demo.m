clear;
clc
folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset']);


datasetname = 'BBC';
filename = sprintf('%s.mat',datasetname);
load(filename);


[~,num_views]=size(data);
for v=1:num_views
	X_views{1,v}=full(data{1,v});
end

[~, n] = size(X_views{1,1});
true_labels=truelabel{1,1}';
cluster_num=length(unique(true_labels));

times_clustering=10;
%%归一化
for v=1:num_views
X_views{v} = X_views{v}./(repmat(sqrt(sum(X_views{v}.^2,1)),size(X_views{v},1),1)+10e-10);
end

method = 'ADIMC';

NMI = zeros(times_clustering, 1);
Acc = zeros(size(NMI));
Purity = zeros(size(NMI));
Fscore = zeros(size(NMI));
ARI = zeros(size(NMI));

max_iter=50;

lambda1_set=10.^[-2:1:2];
lambda2_set=10.^[-2:1:2];
lambda3_set=10.^[-2:1:2];
gamma_set=10.^[-2:1:2];

max_anc=findk(X_views);

		for m=[2]
		for lambda1=lambda1_set
		for lambda2=lambda2_set
		for lambda3=lambda3_set
		for gamma=gamma_set
				anchor_num=min(m*cluster_num,max_anc);
				
				fprintf('%s on %s with lambda1: %f, lambda2: %f, lambda3: %f, gamma: %f, m: %d\n', method,datasetname, lambda1,lambda2,lambda3,gamma,anchor_num);	
				
H_star=zeros(cluster_num, n);					
					
for view_idx = 1:num_views
    % fprintf('\n===== 优化视图 %d/%d =====\n', view_idx, num_views);
    
    % 获取当前视图数据
    Xt = X_views{view_idx};
    
    % 判断是否为第一个视图
    is_first_view = (view_idx == 1);
    
    % 准备历史数据
    if is_first_view
        H_prev = [];
    else
        % 使用前一个视图的结果作为历史
        H_prev = results_variable{view_idx-1}.H_c;
    end
    
    % 运行增量优化算法
    t_start = tic;
    [A_t, Z_t, U_t, H_s, H_c] = ADIMC(...
        Xt, H_prev, lambda1, lambda2, lambda3, gamma, max_iter, anchor_num, cluster_num);
    time_elapsed = toc(t_start);
	
	H_star=H_star+H_s;
    
    % 存储结果
    results_variable{view_idx} = struct(...
        'A_t', A_t, 'U_t', U_t, ...
        'H_s', H_s, 'H_c', H_c, 'Z_t', Z_t, ...
        'time', time_elapsed);
end

					H_star=H_star+results_variable{num_views}.H_c;
					
				for j=1 : times_clustering
					
					results = litekmeans(H_star',cluster_num,'MaxIter',100, 'Replicates',10);

					[Acc(j,1),NMI(j,1),Purity(j,1)]=ClusteringMeasure(true_labels, results);
					[Fscore(j,1), ~,~]=compute_f(true_labels, results);
					[ARI(j,1),~,~]=RandIndex(true_labels, results);
				end
				fprintf('Acc: %f, NMI: %f, Purity: %f, Fscore: %f, ARI: %f\n', mean(Acc), mean(NMI),mean(Purity),mean(Fscore),mean(ARI));
				
		end
		end
		end
		end
		end




